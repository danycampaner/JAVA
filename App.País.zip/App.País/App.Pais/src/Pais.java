public class Pais {
    private String codigo_iso;
    private String nome_pais;
    private double populacao;
    private double dimensao;
    

public Pais() {
    this.codigo_iso = "";
    this.nome_pais = "";
    this.dimensao = 0;
    this.populacao = 0;

}

public Pais (String ISO, String nm, double dim){
    this.codigo_iso = ISO;
    this.nome_pais = nm;
    this.dimensao = dim;
}

public String getcodigo_iso(){
    return this.codigo_iso;

}

public void setcodigo_iso(String c_iso){
    this.codigo_iso = c_iso;
}

public String getnome_pais(){
    return this.nome_pais;
}

public void setnome_pais(String nm){
    this.nome_pais = nm;
}

public double getpopulacao(){
    return this.populacao;
}
public void setpopulacao(double pc){
    this.populacao = pc;
}

public double getdimensao(){
    return this.dimensao;
}
public void setdimensao(double dime){
    this.dimensao = dime;
}

public boolean EhIgual(Pais objP){
    boolean resultado = false;

    if (objP.codigo_iso == this.codigo_iso){
        resultado = true;
    }
    return resultado;
}

public double densidadePopulacional(){
    return this.populacao / this.dimensao;
}

public String maiorPais(Pais obj1, Pais obj2){
    String maiorPais = "";

    if (obj1.dimensao > obj2.dimensao){
        maiorPais = obj1.nome_pais;
    }
    else{
        maiorPais = obj2.nome_pais;
    }
    return maiorPais;
}

public void exibeAtributos (){
    System.out.println("Código ISO: " + this.codigo_iso);
    System.out.println("Nome.......: " + this.nome_pais);
    System.out.println("Dimensão.: " + this.dimensao);
    System.out.println("População: " + this.populacao);
}

}