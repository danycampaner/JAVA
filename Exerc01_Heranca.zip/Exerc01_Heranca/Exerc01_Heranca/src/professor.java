public class professor extends fUNCIONARIO {

    private String disciplina;
  

    public professor(){
        this.disciplina = "";
       
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }
    

    
}
